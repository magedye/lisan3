# Quran Lisan External Source Testing & Capture Addendum v1.0.0

ملحق مستقل مبني على V2.1 وملحق التقاط الأفكار. يوثق توجيهات المالك بشأن استخدام المصادر الخارجية كمولد فرضيات واختبارات دون منحها سلطة على المنهج. لا يعدل V2.1.0 صامتًا.

الملفات الرئيسية:
- `Quran_Lisan_External_Source_Testing_Capture_Addendum_v1.0.0.docx`
- `01_EXTERNAL_SOURCE_HYPOTHESIS_TESTING_POLICY.md`
- `registries/INTAKE_REGISTER.csv`
- `registries/CHANGE_PROPOSAL_REGISTER.csv`
- `registries/METHODOLOGY_FINDINGS.csv`
- `registries/EXTERNAL_HYPOTHESIS_REGISTER_TEMPLATE.csv`
