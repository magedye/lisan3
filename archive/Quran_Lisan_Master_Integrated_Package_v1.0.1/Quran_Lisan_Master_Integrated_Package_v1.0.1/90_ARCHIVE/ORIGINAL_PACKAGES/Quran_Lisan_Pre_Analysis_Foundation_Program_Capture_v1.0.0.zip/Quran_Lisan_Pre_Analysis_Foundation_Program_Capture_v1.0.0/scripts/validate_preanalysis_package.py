from pathlib import Path
import csv,sys
R=Path(__file__).resolve().parents[1]
req=['00_PACKAGE_AUTHORITY.md','01_PRE_ANALYSIS_FOUNDATION_PROGRAM_PROPOSAL.md','02_ROUTE_CARDS.md','03_DEPENDENCY_AND_EXECUTION_SEQUENCE.md','04_VALUE_COMPLEXITY_AND_ENFORCEMENT_MATRIX.md','05_INTEGRATION_MAPPING_TO_V2.1.md','06_OWNER_DECISION_SHEET.md','registries/INTAKE_REGISTER.csv','registries/CHANGE_PROPOSAL_REGISTER.csv','registries/METHODOLOGY_FINDINGS.csv','registries/OPEN_QUESTIONS.csv','acceptance/TEST_CATALOG.csv']
miss=[x for x in req if not (R/x).exists()]
if miss:
 print('PREANALYSIS_PACKAGE: FAIL missing',miss);sys.exit(1)
with (R/'registries/INTAKE_REGISTER.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
errs=[]
for r in rows:
 if r['source_actor']=='ASSISTANT' and r['item_type']=='PROPOSAL' and r['disposition']!='OPEN': errs.append(r['intake_id']+' assistant proposal not OPEN')
for ext in ['INT-PRE-REF-E1','INT-PRE-REF-E2','INT-PRE-REF-E3']:
 if not any(r['intake_id']==ext for r in rows): errs.append('missing '+ext)
if errs:
 print('PREANALYSIS_PACKAGE: FAIL');[print('-',e) for e in errs];sys.exit(1)
print('PREANALYSIS_PACKAGE: PASS')
