# حزمة توثيق مقترح برنامج ما قبل التحليل — لسان القرآن

**الإصدار:** 1.0.0  
**التاريخ:** 2026-09-06  
**النوع:** Capture + Proposal + Integration Planning  
**المرجع الأساس:** Quran Lisan V2.1.0 + Governed Intent Capture Addendum v1.0.0 + External Source Testing Capture Addendum v1.0.0

## الغرض
هذه الحزمة تصوغ وتوثق بصورة صحيحة المقترح السابق الخاص بالمسارات التي ينبغي تجهيزها قبل بدء التحليل الواسع للجذور والمفردات.

لا تعتبر المسارات الجديدة معتمدة لمجرد ورودها في الحزمة. تم الفصل بين:
- توجيهات المالك المقبولة سابقًا؛
- المكونات الموجودة أصلًا في V2.1؛
- المقترحات الجديدة من المساعد التي تبقى `OPEN` حتى يعتمدها المالك؛
- المسارات الخارجية الثلاثة التي سبق التقاط أصلها بوصفه توجيهًا مالكيًا.

## الملفات الرئيسة
1. `00_PACKAGE_AUTHORITY.md`
2. `01_PRE_ANALYSIS_FOUNDATION_PROGRAM_PROPOSAL.md`
3. `02_ROUTE_CARDS.md`
4. `03_DEPENDENCY_AND_EXECUTION_SEQUENCE.md`
5. `04_VALUE_COMPLEXITY_AND_ENFORCEMENT_MATRIX.md`
6. `05_INTEGRATION_MAPPING_TO_V2.1.md`
7. `06_OWNER_DECISION_SHEET.md`
8. `07_FINAL_VERIFICATION.md`
9. `registries/INTAKE_REGISTER.csv`
10. `registries/CHANGE_PROPOSAL_REGISTER.csv`
11. `registries/METHODOLOGY_FINDINGS.csv`
12. `registries/OPEN_QUESTIONS.csv`
13. `acceptance/TEST_CATALOG.csv`

## الحكم
`PROPOSAL_CAPTURED_AND_TRACEABLE`  
ولا يساوي: `OWNER_APPROVED_FOR_INTEGRATION`.
