# خريطة الدمج المقترحة مع V2.1

| المقترح | موضع V2.1 القائم | نوع التغيير المقترح | الحالة |
|---|---|---|---|
| P1 Foundational Profile | `reference/03_METHODOLOGY_AND_EVIDENCE_CONSTITUTION.md` + `reference/17_DECISIONS_AND_OPEN_QUESTIONS.md` | وثيقة/سجل جديد أو قسم versioned | OPEN |
| P2 النص المرجعي | `sources/TANZIL_SOURCE_PROFILE.json` + corpus tools | لا بنية موازية؛ reuse | EXISTING |
| P3 المعرفة الوصفية | `reference/12_DATA_MEMORY_AND_TRACEABILITY_MODEL.md` + occurrence/morphology tools | RootDescriptiveProfile + cache/db | OPEN |
| P4 تأهيل البنية | `GetMorphology`, `GetSyntacticRelations`, source profiles | provenance/qualification contract | OPEN |
| P5 المصطلحات | `reference/02_TERMINOLOGY_AND_LANGUAGE_GOVERNANCE.md` + registry | revision/aliases | OWNER DIRECTIVE; exact wording OPEN |
| P6 منهج/قبول الجذر | `reference/05_ROOT_CONCEPT_CONTRACT.md`, `SK-06`, acceptance | universal-presence tests + batch methodology binding | OWNER RULE exists; integration OPEN |
| P7 المعايرة | `reference/15_TESTING_EVALUATION_ACCEPTANCE.md`, evals | calibration portfolio + sentinel suite | OPEN |
| P8 الذاكرة والعزل | `reference/12_DATA_MEMORY_AND_TRACEABILITY_MODEL.md`, `InternalSnapshot`, prior protocol | accepted-memory + isolation bindings | PARTLY EXISTING / OPEN |
| E1 | Source policy + SK-08/SK-12 + external comparison | reuse external addendum CP-EXT-004 | OWNER ACCEPTED SCOPE |
| E2 | SK-03/SK-04 + cross-root protocol | reuse CP-EXT-008 | OWNER ACCEPTED SCOPE |
| E3 | cross-root protocol | reuse CP-EXT-007 | OWNER ACCEPTED SCOPE |
| Dual lane | `reference/06_SOURCE_ISOLATION_AND_EXTERNAL_COMPARISON.md` + workflow | reuse CP-EXT-009 | OPEN |

## عدم التكرار
لا تُنشئ سجلات جديدة إذا كانت V2.1 تمثل الحقيقة بالفعل. المقترحات الجديدة يجب أن تكون روابط/امتدادات دقيقة، لا record-of-truth موازٍ.
