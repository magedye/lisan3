# مصفوفة القيمة مقابل التعقيد والإنفاذ

| المسار | القيمة | الكلفة | خطر الإفراط | أين يكون الإنفاذ؟ | التوصية الحالية |
|---|---|---|---|---|---|
| P1 | عالية جدًا | منخفضة-متوسطة | تحويل كل افتراض إلى Gate | وثيقة + binding + test | اعتماده Profile خفيف |
| P2 | حرجة | منخفضة | منخفض | Validator/Tool | إبقاء V2.1 كما هو مع ربط البرنامج |
| P3 | عالية جدًا | متوسطة | بناء DB متضخم | Data Contract + deterministic tools | أولوية تنفيذ عالية |
| P4 | عالية | متوسطة | حالات موثوقية كثيرة | Provenance + qualification | أقل عدد حالات يفي بالغرض |
| P5 | عالية | منخفضة-متوسطة | إعادة تسمية تقنية واسعة | Registry + renderer/output | حسم لغة العرض مع compatibility |
| P6 | حرجة | متوسطة | Gate inflation | Method revision + tests | Hard فقط لشروط القبول الجوهرية |
| P7 | عالية جدًا | متوسطة-عالية | تكلفة نماذج/تشغيل | Eval harness | لازم للـScale لا لكل سؤال عابر |
| P8 | عالية | متوسطة | تعقيد lifecycle | Persistence + isolation | استعمل الموجود ووسع بقدر الحاجة |
| E1 | عالية | متوسطة | authority leakage | External hypothesis registry | مهم جدًا |
| E2 | عالية | متوسطة | نقل كتب الصرف كقواعد جاهزة | Cross-root tests | مهم |
| E3 | غير محسومة/محتملة عالية | عالية | overfitting / letter mysticism | broad cross-root evals | استكشافي حتى يثبت |

## قواعد اختيار آلية التنفيذ
1. إذا أمكن حسابه أو التحقق منه حتميًا → Tool/Validator لا Prompt.
2. إذا كان حكمًا دلاليًا → AI/Skill مع أدلة، لا كود يفرض النتيجة.
3. إذا كان مجرد توصية مفيدة → Soft Instruction، لا Gate.
4. إذا كان يخص الاعتماد النهائي فقط → لا يفرض على كل Observation.
5. إذا كانت كلفته عالية وقيمته غير مثبتة → Calibration/Experiment قبل جعله دائمًا.
