# سجل تكامل V2

V2 لا تعيد فتح المنهج الأساسي؛ هي دمج كامل وترقية لعقود البحث والمخرجات.

## مدمج من المرجع السابق
كل مبادئ v1.0.0 المعتمدة، بعد تطبيق تصحيحات v1.0.1 التنفيذية، بما في ذلك الاستقراء الداخلي، العزل، المفهوم الجذري، الفصل الطبقي، الثقة/الاكتمال، المعمارية الهجينة، الأدوات والمهارات والوكلاء.

## مدمج من الإغلاق التنفيذي v1.0.1
Pydantic v2 schemas، Tool Gateway، registries، tests، Tanzil profile، Prototype SLM-01، CAP-GO-01، وrelease reproducibility.

## إضافات V2
1. `SemanticDerivationChain` — سلسلة اشتقاق الدلالة الإلزامية من العام إلى الخاص.
2. `SemanticBoundary` — REQUIRED/PERMITTED/EXCLUDED/UNKNOWN/LOCAL_REALIZATION.
3. `DecisiveContextAssessment` — فصل الشاهد التوضيحي عن السياق الحاسم.
4. `HypothesisOrigin` — تمييز منشأ الفرضية دون جعله معيار صحة.
5. توسيع `FalsificationRun` بالتنبؤات وشروط الإضعاف/الرفض/إعادة الفتح.
6. توسيع `SemanticNeighborResult` إلى Distinction Card قابلة للتدقيق.
7. `SemanticOperatorContribution` لفصل التصريف/الاشتقاق/الصيغة/التركيب العام والموضعي.
8. `RootResearchArtifact`, `TermResearchArtifact`, `VerseSemanticAnalysisArtifact`.
9. `RootCard`/`TermCard` كنماذج عرض مشتقة لا تنشئ حقيقة.
10. `MOADeepReviewReport` كبروتوكول مراجعة اختياري؛ consensus لا يساوي Evidence.
11. `PriorClaimAssessment` لتأهيل المواد السابقة مع الحفاظ على أثرها.
12. `CrossRootConsistencyReview` للمرحلة التي تتجاوز الجذر الأول.
