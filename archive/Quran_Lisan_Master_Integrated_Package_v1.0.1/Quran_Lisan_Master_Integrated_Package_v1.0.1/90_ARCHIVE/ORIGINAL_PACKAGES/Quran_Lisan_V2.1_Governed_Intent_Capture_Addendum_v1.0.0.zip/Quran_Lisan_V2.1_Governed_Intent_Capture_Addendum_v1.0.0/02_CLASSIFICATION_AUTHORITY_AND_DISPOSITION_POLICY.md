# سياسة التصنيف والسلطة والمصير

## 1. الفصل بين المصدر والنوع

`source_actor` يجيب: من أين جاءت النقطة؟  
`item_type` يجيب: ما طبيعتها؟  
`authority_level` يجيب: ما وزنها الحالي؟  
`disposition` يجيب: ماذا قرر المشروع بشأنها؟

لا يجوز دمج هذه الأبعاد في Status واحد.

## 2. Source Actor

- `OWNER`
- `ASSISTANT`
- `AGENT`
- `RESEARCH`
- `SYSTEM`

## 3. Authority Level

- `OWNER_DIRECTIVE`
- `OWNER_PROPOSAL`
- `NON_OWNER_PROPOSAL`
- `RESEARCH_DERIVED`
- `SYSTEM_DERIVED`

وجود `OWNER` كمصدر لا يعني أن كل جملة Directive؛ يجب الحفاظ على speech act قدر الإمكان.

## 4. الحد الأدنى للتوجيه الصريح

عند قول المالك: "أريد/يجب/اعتمد/لا تسمح" في سياق مشروع واضح، يسجل عادةً `OWNER_DIRECTIVE` ما لم يكن النص سؤالًا أو اقتراحًا صريحًا.

## 5. المقترح

كل فكرة يقدمها المساعد أو Agent ولم يعتمدها المالك تسجل `PROPOSAL` و`NON_OWNER_PROPOSAL`.

## 6. Finding

Finding نتج عن تشغيل/بحث لا يصبح Rule. يسجل أولًا في `METHODOLOGY_FINDINGS.csv` ثم، إذا كان عامًا ويستحق التغيير، ينشأ `ChangeProposal` منفصل.

## 7. أخف تمثيل مناسب

عند تحويل نقطة إلى المنهج/التنفيذ، استخدم أخف تمثيل يمنع المشكلة:

`Documentation/Example < Skill Instruction < Requirement/Control < Validator < Gate`

لا تستخدم Gate لمجرد أن الأمر مهم؛ Gate يتطلب enforcer وقرار مرور فعلي.
