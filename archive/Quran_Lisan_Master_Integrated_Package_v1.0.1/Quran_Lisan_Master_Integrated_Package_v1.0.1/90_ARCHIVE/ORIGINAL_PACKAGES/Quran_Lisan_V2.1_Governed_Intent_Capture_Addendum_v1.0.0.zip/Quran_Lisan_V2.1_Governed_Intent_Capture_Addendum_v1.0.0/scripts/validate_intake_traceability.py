from pathlib import Path
import argparse,csv,json,sys,hashlib
ROOT=None
ALLOWED_DISP={'PENDING','ACCEPTED','DEFERRED','REJECTED','SUPERSEDED','OPEN'}
FINAL_NON_TARGET={'DEFERRED','REJECTED','SUPERSEDED','OPEN'}

def parse_json_array(v,name,rowid):
    try: x=json.loads(v or '[]')
    except Exception as e: raise AssertionError(f'{rowid}: {name} invalid JSON: {e}')
    if not isinstance(x,list): raise AssertionError(f'{rowid}: {name} must be array')
    return x

def read_csv(p):
    with p.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def validate(root,release_gate=False):
    errors=[]
    intake_p=root/'registries/INTAKE_REGISTER.csv'; findings_p=root/'registries/METHODOLOGY_FINDINGS.csv'; props_p=root/'registries/CHANGE_PROPOSAL_REGISTER.csv'
    for p in [intake_p,findings_p,props_p]:
        if not p.exists(): errors.append(f'missing {p.relative_to(root)}')
    if errors: return errors
    intake=read_csv(intake_p); props=read_csv(props_p); findings=read_csv(findings_p)
    ids=set(); proposal_ids={r['proposal_id'] for r in props if r.get('proposal_id')}
    for r in intake:
        rid=r['intake_id']
        if not rid: errors.append('blank intake_id'); continue
        if rid in ids: errors.append(f'duplicate intake_id {rid}')
        ids.add(rid)
        if hashlib.sha256(r['raw_statement'].encode()).hexdigest()!=r['raw_statement_sha256']:
            errors.append(f'{rid}: raw_statement_sha256 mismatch')
        try: targets=parse_json_array(r['target_refs_json'],'target_refs_json',rid)
        except AssertionError as e: errors.append(str(e)); targets=[]
        for fn in ['related_ids_json','supersedes_ids_json','superseded_by_ids_json','verification_refs_json']:
            try: parse_json_array(r[fn],fn,rid)
            except AssertionError as e: errors.append(str(e))
        disp=r['disposition']
        if disp not in ALLOWED_DISP: errors.append(f'{rid}: invalid disposition {disp}')
        if disp=='ACCEPTED' and not targets: errors.append(f'{rid}: ACCEPTED requires target_refs')
        if r['implementation_state'] in {'IMPLEMENTED','VERIFIED'} and not targets: errors.append(f'{rid}: {r["implementation_state"]} requires target_refs')
        if r['item_type']=='PROPOSAL' and r['source_actor'] in {'ASSISTANT','AGENT','RESEARCH'} and disp=='ACCEPTED' and not r['approval_ref']:
            errors.append(f'{rid}: non-owner accepted proposal requires approval_ref')
        if disp=='SUPERSEDED':
            supers=parse_json_array(r['superseded_by_ids_json'],'superseded_by_ids_json',rid)
            if not supers and not r['rationale']: errors.append(f'{rid}: SUPERSEDED needs superseded_by or rationale')
        if release_gate:
            if r['status']!='CLOSED': errors.append(f'{rid}: release gate requires CLOSED status')
            if not targets and disp not in FINAL_NON_TARGET: errors.append(f'{rid}: release gate requires target_refs or explicit non-target disposition')
    for r in findings:
        fid=r.get('finding_id') or '<blank finding>'
        try: parse_json_array(r.get('evidence_refs_json','[]'),'evidence_refs_json',fid)
        except AssertionError as e: errors.append(str(e))
        if r.get('status')=='PROPOSAL_CREATED':
            pid=r.get('proposal_id')
            if not pid or pid not in proposal_ids: errors.append(f'{fid}: PROPOSAL_CREATED requires existing proposal_id')
    for r in props:
        pid=r.get('proposal_id') or '<blank proposal>'
        try:
            srcs=parse_json_array(r.get('source_intake_ids_json','[]'),'source_intake_ids_json',pid)
            parse_json_array(r.get('enforcement_loci_json','[]'),'enforcement_loci_json',pid)
            parse_json_array(r.get('required_tests_json','[]'),'required_tests_json',pid)
            for x in srcs:
                if x not in ids: errors.append(f'{pid}: unknown source intake {x}')
        except AssertionError as e: errors.append(str(e))
        if r.get('status') in {'ACCEPTED','IMPLEMENTED','VERIFIED'} and not r.get('decision_ref'):
            errors.append(f'{pid}: {r.get("status")} requires decision_ref')
    return errors

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); ap.add_argument('--release-gate',action='store_true'); args=ap.parse_args()
    root=Path(args.root).resolve(); errs=validate(root,args.release_gate)
    if errs:
        print('INTAKE_TRACEABILITY: FAIL')
        for e in errs: print('-',e)
        raise SystemExit(1)
    print('INTAKE_TRACEABILITY: PASS', '(release-gate)' if args.release_gate else '')
if __name__=='__main__': main()
