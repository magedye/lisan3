from pathlib import Path
import hashlib,json,sys,argparse
ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); a=ap.parse_args(); root=Path(a.root).resolve()
m=json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
errs=[]
for e in m['files']:
    p=root/e['path']
    if not p.exists(): errs.append(f"missing {e['path']}"); continue
    b=p.read_bytes(); h=hashlib.sha256(b).hexdigest()
    if h!=e['sha256']: errs.append(f"hash mismatch {e['path']}")
    if len(b)!=e['size']: errs.append(f"size mismatch {e['path']}")
if errs:
    print('PACKAGE_VALIDATION: FAIL'); [print('-',x) for x in errs]; raise SystemExit(1)
print('PACKAGE_VALIDATION: PASS',len(m['files']),'tracked files')
