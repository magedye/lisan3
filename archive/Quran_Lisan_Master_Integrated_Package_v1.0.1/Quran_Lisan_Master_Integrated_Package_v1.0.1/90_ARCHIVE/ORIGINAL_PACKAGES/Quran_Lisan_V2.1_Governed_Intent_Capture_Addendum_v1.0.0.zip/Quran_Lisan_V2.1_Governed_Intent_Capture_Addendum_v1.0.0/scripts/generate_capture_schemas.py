from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'contracts/python'))
from quran_lisan_capture_contracts.records import IntakeRecord, MethodologyFinding, ChangeProposal
OUT=ROOT/'contracts/schemas'; OUT.mkdir(parents=True,exist_ok=True)
for model in [IntakeRecord, MethodologyFinding, ChangeProposal]:
    (OUT/f'{model.__name__}.schema.json').write_text(json.dumps(model.model_json_schema(),ensure_ascii=False,indent=2),encoding='utf-8')
print('GENERATED',3)
