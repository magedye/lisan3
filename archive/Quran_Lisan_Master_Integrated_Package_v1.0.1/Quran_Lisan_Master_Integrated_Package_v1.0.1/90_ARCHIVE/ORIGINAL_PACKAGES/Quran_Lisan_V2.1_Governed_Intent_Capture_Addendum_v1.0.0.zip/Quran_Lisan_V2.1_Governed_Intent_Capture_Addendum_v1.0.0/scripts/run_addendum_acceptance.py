from pathlib import Path
import csv, json, tempfile, shutil, subprocess, sys, hashlib
ROOT=Path(__file__).resolve().parents[1]

def run(args,expect):
    p=subprocess.run([sys.executable,str(ROOT/'scripts/validate_intake_traceability.py'),'--root',str(args)],capture_output=True,text=True)
    if (p.returncode==0)!=expect:
        print(p.stdout,p.stderr); raise SystemExit('unexpected validator result')

# positive package
run(ROOT,True)
run(ROOT,True)  # normal gate
p=subprocess.run([sys.executable,str(ROOT/'scripts/validate_intake_traceability.py'),'--root',str(ROOT),'--release-gate'],capture_output=True,text=True)
if p.returncode: print(p.stdout,p.stderr); raise SystemExit('release gate should pass')

# negative: accepted assistant proposal without approval_ref
with tempfile.TemporaryDirectory() as td:
    t=Path(td); shutil.copytree(ROOT/'registries',t/'registries')
    p=t/'registries/INTAKE_REGISTER.csv'
    with p.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f); fields=reader.fieldnames; rows=list(reader)
    raw='اقتراح غير مالكي يجب ألا يعتمد بلا موافقة.'
    rows.append({'intake_id':'INT-NEG-001','parent_intake_id':'','source_actor':'ASSISTANT','authority_level':'NON_OWNER_PROPOSAL','source_reference':'fixture','captured_at':'2026-09-06T00:00:00+03:00','raw_statement':raw,'raw_statement_sha256':hashlib.sha256(raw.encode()).hexdigest(),'normalized_statement':raw,'item_type':'PROPOSAL','scope':'TEST','status':'CLOSED','disposition':'ACCEPTED','implementation_state':'PENDING','target_refs_json':json.dumps(['x']),'related_ids_json':'[]','approval_ref':'','supersedes_ids_json':'[]','superseded_by_ids_json':'[]','rationale':'','verification_refs_json':'[]'})
    with p.open('w',encoding='utf-8-sig',newline='') as f: w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    run(t,False)
print('ADDENDUM_SELF_TESTS: PASS')
