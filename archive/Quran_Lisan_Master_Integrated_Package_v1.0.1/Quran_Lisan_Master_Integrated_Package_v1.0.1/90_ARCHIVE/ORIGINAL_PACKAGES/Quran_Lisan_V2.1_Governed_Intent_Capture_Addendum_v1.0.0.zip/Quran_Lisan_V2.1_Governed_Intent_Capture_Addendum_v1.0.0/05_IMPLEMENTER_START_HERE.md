# Implementer Start Here

1. اقرأ `00_ADDENDUM_AUTHORITY.md`.
2. أضف عنصرًا جديدًا إلى `registries/INTAKE_REGISTER.csv` عند ظهور نقطة جوهرية.
3. فك الرسائل متعددة النقاط إلى صفوف ذرية باستخدام `parent_intake_id`.
4. صنف كل صف.
5. اربطه بالهدف في V2.1 أو سجل disposition صريحًا.
6. استخدم `METHODOLOGY_FINDINGS.csv` للدروس الناتجة عن البحث/التجارب.
7. استخدم `CHANGE_PROPOSAL_REGISTER.csv` فقط للتغييرات المقترحة؛ لا تجعل الاقتراح سلطة مباشرة.
8. شغّل:

```bash
python scripts/validate_intake_traceability.py --root .
python scripts/validate_intake_traceability.py --root . --release-gate
```

9. قبل دمج الملحق في إصدار لاحق، طبق registry patches ثم أضف traceability/tests إلى الحزمة الأساسية.
