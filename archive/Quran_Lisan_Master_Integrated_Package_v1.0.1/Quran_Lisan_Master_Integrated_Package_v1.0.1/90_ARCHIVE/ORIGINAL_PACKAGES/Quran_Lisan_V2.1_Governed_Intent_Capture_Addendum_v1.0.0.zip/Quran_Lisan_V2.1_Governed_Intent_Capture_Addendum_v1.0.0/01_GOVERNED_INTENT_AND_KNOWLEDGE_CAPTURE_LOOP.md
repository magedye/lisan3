# Governed Intent & Knowledge Capture Loop

## 1. الهدف

إنشاء حلقة منخفضة التكلفة تمنع فقدان الأفكار والتوجيهات والدروس بين المحادثة والتنفيذ، من دون تحويل كل محادثة إلى عملية حوكمة ثقيلة.

## 2. المسار الإلزامي

```text
Statement / Finding
      ↓
CAPTURE
      ↓
ATOMIZE
      ↓
CLASSIFY
      ↓
MAP
      ↓
DISPOSITION
      ↓
UPDATE / LINK
      ↓
VERIFY TRACEABILITY
      ↓
CLOSE / DEFER / REJECT / SUPERSEDE / OPEN
```

## 3. CAPTURE

يحفظ النص الأصلي مع:

- `source_actor`
- `source_reference`
- `captured_at`
- `raw_statement`
- `raw_statement_sha256`

لا يشترط اتخاذ قرار عند الالتقاط.

## 4. ATOMIZE

إذا احتوت الرسالة أكثر من طلب/فكرة، تنشأ صفوف ذرية مستقلة ترتبط بـ`parent_intake_id`.

مثال:

> ادرس الجذر، ووضح أثر الصيغة، ولا تستخدم المعاجم داخليًا، واحفظ النتائج القوية.

تنتج أربع وحدات مستقلة، حتى لا ينفذ بعضها ويضيع بعضها.

## 5. CLASSIFY

القيم المعتمدة:

- `OWNER_DIRECTIVE`
- `METHODOLOGY_PRINCIPLE`
- `REQUIREMENT`
- `CONTROL`
- `TERMINOLOGY`
- `DECISION`
- `OPEN_QUESTION`
- `PROPOSAL`
- `RESEARCH_FINDING`
- `EVAL_CASE`
- `IMPLEMENTATION_NOTE`

التصنيف لا يحدد السلطة وحده؛ `source_actor` و`authority_level` يبقيان منفصلين.

## 6. MAP

يربط العنصر بأدنى موضع مناسب داخل V2.1. أمثلة:

| العنصر | الموضع المتوقع |
|---|---|
| متطلب | `REQUIREMENTS_REGISTRY.csv` + اختبار |
| ضابط | `CONTROL_REGISTRY.csv` + enforcer إن لزم |
| قرار | `DECISION_REGISTER.csv` |
| مصطلح | `TERMINOLOGY_REGISTRY.csv` |
| سؤال مفتوح | `OPEN_QUESTIONS.csv` |
| اقتراح | `CHANGE_PROPOSAL_REGISTER.csv` حتى الاعتماد |
| Finding منهجي | `METHODOLOGY_FINDINGS.csv` ثم Proposal إذا كان عامًا |
| Eval case | `acceptance/TEST_CATALOG.csv` أو eval fixture |

## 7. DISPOSITION

القيم النهائية المسموح بها:

- `ACCEPTED`
- `DEFERRED`
- `REJECTED`
- `SUPERSEDED`
- `OPEN`

أما `implementation_state` فيمثل أثر التنفيذ:

- `NOT_APPLICABLE`
- `PENDING`
- `IMPLEMENTED`
- `VERIFIED`

وبذلك لا نخلط قرار قبول الفكرة مع حالة تنفيذها.

## 8. قاعدة الاقتراحات غير المالكية

إذا كان العنصر `PROPOSAL` ومصدره `ASSISTANT` أو `AGENT` أو `RESEARCH`, فلا يجوز أن يصبح `ACCEPTED` من دون `approval_ref` يثبت جهة الاعتماد المناسبة.

## 9. قاعدة عدم الضياع

في Release/Methodology reconciliation gate، يفشل التحقق إذا وجد:

- Intake مقبول بلا `target_refs`.
- Intake ما زال `CAPTURED` أو `ROUTED` بلا disposition بعد إغلاق دورة المراجعة.
- Proposal غير مالكي مقبول بلا `approval_ref`.
- عنصر `IMPLEMENTED/VERIFIED` بلا موضع تنفيذ مرتبط.

## 10. المصالحة الدورية

تنفذ `Intake Reconciliation` بعد:

- دفعة بحث جذور.
- إصدار منهجي.
- مجموعة تغييرات كبيرة.
- قبل إصدار حزمة جديدة.

وتجيب عن:

1. ما العناصر غير المصنفة؟
2. ما المقترحات المفتوحة؟
3. ما المقبول بلا أثر؟
4. ما القرار الذي لم ينعكس على التنفيذ؟
5. ما المؤجل الذي أصبح وقت تنفيذه؟
6. ما التعارضات أو العناصر التي يجب أن تصبح `SUPERSEDED`؟
7. ما الـFindings التي تكررت بما يكفي لاقتراح تغيير منهجي؟
8. ما الحالات التي يجب تحويلها إلى Eval/Regression؟
