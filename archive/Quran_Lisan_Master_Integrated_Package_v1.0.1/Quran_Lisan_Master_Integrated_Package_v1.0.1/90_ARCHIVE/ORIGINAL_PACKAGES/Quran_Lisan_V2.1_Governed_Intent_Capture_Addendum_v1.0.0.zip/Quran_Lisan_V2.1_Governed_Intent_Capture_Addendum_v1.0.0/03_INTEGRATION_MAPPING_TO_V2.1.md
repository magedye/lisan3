# خريطة دمج الملحق مع V2.1

## 1. الملفات الجديدة

يضيف الملحق عند دمجه:

- `registries/INTAKE_REGISTER.csv`
- `registries/METHODOLOGY_FINDINGS.csv`
- `registries/CHANGE_PROPOSAL_REGISTER.csv`
- عقود Pydantic/JSON Schema المقابلة.
- `scripts/validate_intake_traceability.py`

ولا ينشئ نسخة ثانية من `OPEN_QUESTIONS.csv`؛ يستخدم الموجود في V2.1.

## 2. الرقع المقترحة للسجلات الحاكمة

توجد رقع CSV تحت `integration/registry-patches/` لإضافة ضوابط/متطلبات/قرارات/مصطلحات/اختبارات ذات صلة عند دمج الملحق في إصدار لاحق.

## 3. مواضع الربط

`INTAKE_REGISTER.target_refs_json` قد يشير إلى IDs أو paths من:

- Registries.
- Research contracts.
- Skills.
- Schemas.
- Tools.
- Tests/Evals.
- Implementation artifacts.

## 4. SOURCE_TRACEABILITY

عند الدمج الكامل في إصدار لاحق، يضاف أصل هذا الملحق إلى `SOURCE_TRACEABILITY.csv` لكل سجل/عقد تم إدخاله، ولا تعد ملفات المحادثة مصدر تنفيذ مباشر بعد إصدار الحزمة المدمجة.

## 5. CHANGELOG

كل Intake مقبول نتج عنه تغيير حاكم يجب أن يظهر إما مباشرة في Changelog أو عبر Decision/Requirement مرتبط يظهر في Changelog، حتى يمكن تفسير سبب التغيير لاحقًا.
