# معايير القبول والتحقق

## A. اختبارات ثابتة

1. Headers السجلات صحيحة.
2. IDs فريدة.
3. حقول JSON قابلة للتحليل.
4. `raw_statement_sha256` يطابق النص الأصلي.
5. `CLOSED + ACCEPTED` يتطلب `target_refs_json` غير فارغ.
6. `IMPLEMENTED/VERIFIED` يتطلب target refs.
7. Proposal غير مالكي لا يقبل دون `approval_ref`.
8. Release gate يرفض Intake غير مصفى بلا disposition/target.
9. `SUPERSEDED` يتطلب `superseded_by_ids_json` أو rationale يفسر المصير.
10. Findings العامة التي تنتج Proposal تحمل `proposal_id` صالحًا.

## B. معيار عدم الضياع

قبل Release أو Methodology Revision:

> كل Intake جوهري إما وصل إلى أثر حاكم/تنفيذي قابل للتتبع، أو له قرار صريح يفسر لماذا لم يصل.

## C. ما لا يثبته النجاح

نجاح Validator لا يثبت أن قرار التصنيف نفسه صحيح معرفيًا؛ يثبت فقط عدم وجود عنصر مفقود أو رابط مكسور وفق العقود.
