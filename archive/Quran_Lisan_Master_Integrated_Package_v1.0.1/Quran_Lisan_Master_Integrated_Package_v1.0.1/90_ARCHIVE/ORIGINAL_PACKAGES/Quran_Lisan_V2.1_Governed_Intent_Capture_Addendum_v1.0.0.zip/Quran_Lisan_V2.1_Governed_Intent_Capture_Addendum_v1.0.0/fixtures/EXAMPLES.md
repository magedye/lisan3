# أمثلة تشغيلية

## مثال 1 — رسالة مالك متعددة النقاط

الرسالة:

> يجب توضيح دلالة الجذر ثم أثر الصيغة، وأقترح أيضًا اختبار held-out cases.

التمثيل:

- Intake A: `OWNER_DIRECTIVE` — ترتيب الجذر ثم الصيغة → Requirement/Control.
- Intake B: `PROPOSAL` — held-out cases → ChangeProposal حتى الاعتماد.

لا يدمجان في صف واحد.

## مثال 2 — اقتراح Agent

Agent يقترح Graph DB.

- يسجل `PROPOSAL`.
- لا يدخل Architecture Decision تلقائيًا.
- إذا رفض: `REJECTED` + rationale.
- إذا أجل: `DEFERRED`.
- إذا قبل: `approval_ref` + Decision/Requirement target.

## مثال 3 — Finding من حملة الجذور

ظهور خلط متكرر بين أثر الصيغة والجذر في 4 جذور:

- يسجل `METHODOLOGY_FINDING` مع evidence refs والتكرار.
- إذا كان عامًا: ChangeProposal من أخف نوع مناسب، غالبًا Skill/Test قبل Gate.
- بعد القرار فقط يعدل المنهج.
