from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from typing import List
from pydantic import BaseModel, ConfigDict, Field, model_validator
import hashlib

class StrictRecord(BaseModel):
    model_config = ConfigDict(extra='forbid')

class SourceActor(StrEnum):
    OWNER='OWNER'; ASSISTANT='ASSISTANT'; AGENT='AGENT'; RESEARCH='RESEARCH'; SYSTEM='SYSTEM'
class AuthorityLevel(StrEnum):
    OWNER_DIRECTIVE='OWNER_DIRECTIVE'; OWNER_PROPOSAL='OWNER_PROPOSAL'; NON_OWNER_PROPOSAL='NON_OWNER_PROPOSAL'; RESEARCH_DERIVED='RESEARCH_DERIVED'; SYSTEM_DERIVED='SYSTEM_DERIVED'
class IntakeType(StrEnum):
    OWNER_DIRECTIVE='OWNER_DIRECTIVE'; METHODOLOGY_PRINCIPLE='METHODOLOGY_PRINCIPLE'; REQUIREMENT='REQUIREMENT'; CONTROL='CONTROL'; TERMINOLOGY='TERMINOLOGY'; DECISION='DECISION'; OPEN_QUESTION='OPEN_QUESTION'; PROPOSAL='PROPOSAL'; RESEARCH_FINDING='RESEARCH_FINDING'; EVAL_CASE='EVAL_CASE'; IMPLEMENTATION_NOTE='IMPLEMENTATION_NOTE'
class IntakeStatus(StrEnum): CAPTURED='CAPTURED'; ROUTED='ROUTED'; CLOSED='CLOSED'
class Disposition(StrEnum): PENDING='PENDING'; ACCEPTED='ACCEPTED'; DEFERRED='DEFERRED'; REJECTED='REJECTED'; SUPERSEDED='SUPERSEDED'; OPEN='OPEN'
class ImplementationState(StrEnum): NOT_APPLICABLE='NOT_APPLICABLE'; PENDING='PENDING'; IMPLEMENTED='IMPLEMENTED'; VERIFIED='VERIFIED'
class FindingCategory(StrEnum):
    METHOD_GAP='METHOD_GAP'; METHOD_AMBIGUITY='METHOD_AMBIGUITY'; METHOD_OVERCONSTRAINT='METHOD_OVERCONSTRAINT'; METHOD_UNDERSPECIFICATION='METHOD_UNDERSPECIFICATION'; FALSE_BLOCKER='FALSE_BLOCKER'; DATA_GAP='DATA_GAP'; SOURCE_GAP='SOURCE_GAP'; TOOL_GAP='TOOL_GAP'; SCHEMA_GAP='SCHEMA_GAP'; OUTPUT_GAP='OUTPUT_GAP'; CONFIDENCE_GAP='CONFIDENCE_GAP'; LAYER_CONFLATION_RISK='LAYER_CONFLATION_RISK'; COVERAGE_COST='COVERAGE_COST'; PERFORMANCE_COST='PERFORMANCE_COST'; RECURRING_FAILURE='RECURRING_FAILURE'; UNEXPECTED_INSIGHT='UNEXPECTED_INSIGHT'
class FindingSeverity(StrEnum): LOW='LOW'; MEDIUM='MEDIUM'; HIGH='HIGH'; CRITICAL='CRITICAL'
class FindingStatus(StrEnum): OPEN='OPEN'; PROPOSAL_CREATED='PROPOSAL_CREATED'; RESOLVED='RESOLVED'; DEFERRED='DEFERRED'; REJECTED='REJECTED'
class ProposalStatus(StrEnum): PROPOSED='PROPOSED'; ACCEPTED='ACCEPTED'; REJECTED='REJECTED'; DEFERRED='DEFERRED'; SUPERSEDED='SUPERSEDED'; IMPLEMENTED='IMPLEMENTED'; VERIFIED='VERIFIED'

class IntakeRecord(StrictRecord):
    intake_id: str
    parent_intake_id: str|None=None
    source_actor: SourceActor
    authority_level: AuthorityLevel
    source_reference: str
    captured_at: datetime
    raw_statement: str
    raw_statement_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    normalized_statement: str
    item_type: IntakeType
    scope: str
    status: IntakeStatus=IntakeStatus.CAPTURED
    disposition: Disposition=Disposition.PENDING
    implementation_state: ImplementationState=ImplementationState.PENDING
    target_refs: List[str]=[]
    related_ids: List[str]=[]
    approval_ref: str|None=None
    supersedes_ids: List[str]=[]
    superseded_by_ids: List[str]=[]
    rationale: str|None=None
    verification_refs: List[str]=[]

    @model_validator(mode='after')
    def consistency(self):
        actual=hashlib.sha256(self.raw_statement.encode()).hexdigest()
        if actual != self.raw_statement_sha256:
            raise ValueError('raw_statement_sha256 mismatch')
        if self.disposition == Disposition.ACCEPTED and not self.target_refs:
            raise ValueError('ACCEPTED intake requires target_refs')
        if self.implementation_state in {ImplementationState.IMPLEMENTED, ImplementationState.VERIFIED} and not self.target_refs:
            raise ValueError('implemented/verified intake requires target_refs')
        if self.item_type == IntakeType.PROPOSAL and self.source_actor in {SourceActor.ASSISTANT,SourceActor.AGENT,SourceActor.RESEARCH} and self.disposition == Disposition.ACCEPTED and not self.approval_ref:
            raise ValueError('non-owner proposal requires approval_ref before ACCEPTED')
        if self.disposition == Disposition.SUPERSEDED and not self.superseded_by_ids and not self.rationale:
            raise ValueError('SUPERSEDED requires superseded_by_ids or rationale')
        return self

class MethodologyFinding(StrictRecord):
    finding_id: str
    intake_id: str|None=None
    source_run_ref: str|None=None
    root_ref: str|None=None
    methodology_version: str
    category: FindingCategory
    description: str
    evidence_refs: List[str]=[]
    severity: FindingSeverity
    frequency: int=1
    generalizable: bool=False
    proposed_representation: str|None=None
    proposal_id: str|None=None
    status: FindingStatus=FindingStatus.OPEN
    rationale: str|None=None

    @model_validator(mode='after')
    def proposal_consistency(self):
        if self.status == FindingStatus.PROPOSAL_CREATED and not self.proposal_id:
            raise ValueError('PROPOSAL_CREATED finding requires proposal_id')
        return self

class ChangeProposal(StrictRecord):
    proposal_id: str
    source_intake_ids: List[str]
    title: str
    proposal_type: str
    target_role: str
    target_path: str|None=None
    scope: str
    proposed_change: str
    rationale: str
    expected_value: str
    expected_cost: str
    risk_of_change: str
    enforcement_loci: List[str]=[]
    required_tests: List[str]=[]
    approval_authority: str
    status: ProposalStatus=ProposalStatus.PROPOSED
    decision_ref: str|None=None
    version_impact: str

    @model_validator(mode='after')
    def accepted_requires_decision(self):
        if self.status in {ProposalStatus.ACCEPTED,ProposalStatus.IMPLEMENTED,ProposalStatus.VERIFIED} and not self.decision_ref:
            raise ValueError('accepted/implemented/verified proposal requires decision_ref')
        return self
