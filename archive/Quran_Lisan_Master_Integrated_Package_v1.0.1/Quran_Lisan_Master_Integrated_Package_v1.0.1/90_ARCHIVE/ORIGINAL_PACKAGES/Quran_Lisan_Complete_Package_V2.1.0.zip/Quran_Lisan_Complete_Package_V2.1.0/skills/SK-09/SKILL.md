# SK-09 — مقارنة الجيران والسمة الفارقة

**الإصدار:** 2.0.0  
**الحالة:** ACCEPTED  
**المتطلبات:** FR-013|CTL-010

## الهدف
مقارنة الجيران والسمة الفارقة وفق دستور V2 وعقوده التنفيذية والبحثية.

## المدخلات
target + neighbor + comparable evidence

## السياق المسموح
- في `INTERNAL_ANALYSIS`: Tanzil/البيانات البنيوية المصرح بها، ملاحظات التشغيل الحالي، وعقود المشروع فقط.
- لا تستخدم نتائج سابقة كدليل؛ يمكن أن تكون فرضية تشغيلية إذا أعيد تتبع أصلها.

## الأدوات المسموحة
TL-01|TL-07|TL-08

## الخطوات الإلزامية
1. تحقق من وحدة التحليل والمرحلة وسياسة المصدر.
2. استدع الأدوات اللازمة وسجل `ExecutionReceipt`; لا تدع تنفيذًا بلا receipt.
3. افصل observation (الملاحظة) عن hypothesis (الفرضية) وعن evidence relation (علاقة الدليل).
4. طبق الفصل الطبقي الملائم للمهمة، وسجل الغموض والفجوات بدل ملئها تخمينًا.
5. أنشئ المخرج المنظم، ثم تحقق منه ضد schema قبل تسليمه للمنسق.

## المخرجات
shared dimensions + established/unresolved differences + substitution cases

## حالات الفشل/عدم الحسم
NO_DIFFERENCE_ESTABLISHED نتيجة صحيحة؛ يمنع اختراع فرق

## شرط التوقف
تتوقف المهارة عند تحقق عقد مخرجها أو عند ظهور نقص يمنع تنفيذ خطوة إلزامية. لا تكرر حلقة اعتراض بلا اختبار جديد قابل للتتبع.

## التحقق
- schema validation.
- source-policy validation.
- evidence-reference validation عند وجود ادعاء.
- receipt presence للأدوات/النماذج المؤثرة.

## ممنوعات
- Chain-of-thought (سلسلة التفكير الداخلية الخاصة) ليست Artifact مطلوبًا؛ نحفظ أسبابًا موجزة قابلة للمراجعة فقط.
- لا يتحول retrieval similarity أو موافقة نموذج ثان إلى دليل دلالي بذاته.


## V2 — Distinction Card
تسجل shared territory وtarget/neighbor residue وsame-context collisions وcounterfactual substitution losses وما بقي غير محسوم. الاستبدال الافتراضي ليس Evidence مستقلًا.
