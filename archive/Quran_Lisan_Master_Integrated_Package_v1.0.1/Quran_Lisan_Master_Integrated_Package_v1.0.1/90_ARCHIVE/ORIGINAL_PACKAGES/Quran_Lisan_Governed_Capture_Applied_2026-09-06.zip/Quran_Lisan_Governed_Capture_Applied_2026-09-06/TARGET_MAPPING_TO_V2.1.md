# Target Mapping to V2.1

This file is a routing map only; it does not modify V2.1.

| Area | Existing V2.1 target | Proposed addition/change |
|---|---|---|
| Foundational premises | `reference/03_METHODOLOGY_AND_EVIDENCE_CONSTITUTION.md` | New `reference/20_FOUNDATIONAL_PREMISES_AND_ASSUMPTIONS_CHARTER.md` + register |
| Terminology | `reference/02_TERMINOLOGY_AND_LANGUAGE_GOVERNANCE.md`, `TERMINOLOGY_REGISTRY.csv` | Clarify/reduce ambiguous `دلالة`; deprecate governing use of `الوحدة المعجمية` in Arabic output |
| Root concept | `reference/05_ROOT_CONCEPT_CONTRACT.md`, SK-06, RootResearchArtifact | Add universal-presence criterion and remove conflicting accepted path to `ROOT_MULTIPLE_LEXICAL_UNITS` for a confirmed single root |
| Confidence | `reference/13_CONFIDENCE_COMPLETENESS_VERIFICATION.md` | Add optional robustness tests and campaign calibration policy |
| Campaign | Roadmap + cross-root protocol | Add persistent campaign workflow, batch freeze, sentinels, findings loop |
| Open questions | `registries/OPEN_QUESTIONS.csv` | Apply `integration/OPEN_QUESTIONS_PATCH.csv` after review |
