# Quran Lisan — Governed Capture Applied

This package applies the V2.1 Governed Intent Capture Addendum to `Pasted markdown(20260905-234930).md`.

It is **not** a new methodology version and does **not** modify V2.1. It is a reconciled intake/change set ready for owner review and later integration.

## Files
- `registries/INTAKE_REGISTER.csv` — atomized statements and dispositions.
- `registries/METHODOLOGY_FINDINGS.csv` — methodology-level findings detected during reconciliation.
- `registries/CHANGE_PROPOSAL_REGISTER.csv` — proposed changes, not silently accepted.
- `integration/OPEN_QUESTIONS_PATCH.csv` — questions to add to the existing V2.1 open-question register if approved.
- `INTAKE_RECONCILIATION_REPORT.md` — human summary.
- `TARGET_MAPPING_TO_V2.1.md` — where each area belongs.
- `evidence/SOURCE_LINE_MAP.csv` — source traceability.

## Authority rule
Assistant-origin proposals remain open unless independently approved. Latest explicit owner directives override conflicting earlier assistant proposals.
