# ابدأ من هنا — دليل المطور

1. اقرأ `00_RELEASE_AUTHORITY.md` ثم `01_CLOSURE_DECISIONS.md`.
2. شغّل `python scripts/run_closure_acceptance.py`؛ يجب أن ينجح قبل كتابة المنتج.
3. اقتنِ Tanzil عبر `scripts/acquire_tanzil.py` أو ضع القطعة المعروفة ثم شغّل `validate_tanzil.py`.
4. استخدم Pydantic models في `contracts/python/quran_lisan_contracts` كمصدر عقود، ولا تخترع حقولًا إضافية.
5. نفذ Tool Gateway وفق `contracts/tools/TOOL_REGISTRY.csv` وOpenAPI.
6. نفذ State Machine وفق `contracts/state-machine/research_run_transitions.json`.
7. أدخل Fixture `PROTOTYPE-SLM-01` فقط في النموذج الأول؛ لا توسع إلى جذور أخرى قبل `GQ-001` أو قرار Phase جديد.
8. طبق Skills 01–13 كما هي؛ Agent يختار Skill لكنه لا يغير منهجها.
9. شغّل الاختبارات من `acceptance/TEST_CATALOG.csv`; الاختبارات المصنفة `SEMANTIC_EVAL` لا تحتاج معنى متوقعًا مسبقًا، بل Rubric سلوكيًا.
10. لا تعتمد Opal منسقًا حاكمًا حتى CAP-GO-01 = PASS 10/10؛ Python fallback هو الافتراضي الآمن.

إذا احتجت قرارًا غير موثق: أنشئ `SPEC_GAP` وتوقف عن الجزء المتأثر.
