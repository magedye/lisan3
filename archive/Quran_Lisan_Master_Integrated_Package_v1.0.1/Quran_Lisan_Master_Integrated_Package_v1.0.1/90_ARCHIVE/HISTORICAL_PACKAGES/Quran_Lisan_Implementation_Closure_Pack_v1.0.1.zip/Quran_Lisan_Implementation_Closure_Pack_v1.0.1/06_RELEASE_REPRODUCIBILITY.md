# إعادة إنتاج الإصدار

## بيئة الهدف
- Python Runtime المستهدف: 3.12.
- Pydantic: 2.13.4 في عقود الإغلاق.
- FastAPI: 0.128.2 في عقد OpenAPI المرجعي.

## خطوات الإغلاق
```bash
python scripts/run_closure_acceptance.py
python scripts/build_release.py
python scripts/validate_package.py
python scripts/create_release_zip.py
```
بعد إنشاء DOCX الموحد وتشغيل QA البيئي، يشغّل `build_release.py` مرة أخرى ثم `validate_package.py`، وبعد نجاحهما ينشئ `create_release_zip.py` ملف ZIP وبصمة SHA-256 جانبية.

## قاعدة DOCX
يُسجل renderer (برنامج التصيير)، الإصدار، OS، الخطوط المستخدمة، عدد الصفحات الناتج، وبصمات الصور/لوحات المراجعة في `release-evidence/docx/`. الحكم هو `DOCX_VISUAL_QA_PASS_IN_RECORDED_ENVIRONMENT` ولا يدعي ثبات عدد الصفحات في Microsoft Word أو أي Renderer آخر.
